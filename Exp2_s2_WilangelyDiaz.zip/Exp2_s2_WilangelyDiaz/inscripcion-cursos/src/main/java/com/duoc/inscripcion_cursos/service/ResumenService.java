package com.duoc.inscripcion_cursos.service;

import com.duoc.inscripcion_cursos.model.Curso;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

@Service
public class ResumenService {

    public String generarResumen(Curso curso) throws IOException {

        String nombreArchivo = "resumen-" + curso.getId() + ".txt";

        File archivo = new File(nombreArchivo);

        FileWriter writer = new FileWriter(archivo);

        writer.write("RESUMEN DEL CURSO\n");
        writer.write("-----------------\n");
        writer.write("ID: " + curso.getId() + "\n");
        writer.write("Nombre: " + curso.getNombre() + "\n");
        writer.write("Instructor: " + curso.getInstructor() + "\n");
        writer.write("Duración: " + curso.getDuracion() + " horas\n");
        writer.write("Costo: $" + curso.getCosto() + "\n");

        writer.close();

        return archivo.getAbsolutePath();
    }
}